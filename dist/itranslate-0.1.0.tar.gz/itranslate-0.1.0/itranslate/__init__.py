"""Init."""
__version__ = "0.1.0"
from .itranslate import itranslate
from .itranslate import atranslate

__all__ = ("itranslate", "itranslate",)
