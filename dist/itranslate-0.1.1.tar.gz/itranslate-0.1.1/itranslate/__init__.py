"""Init."""
__version__ = "0.1.1"
from .itranslate import itranslate
from .atranslate import atranslate

__all__ = (
    "itranslate",
    "atranslate",
)
